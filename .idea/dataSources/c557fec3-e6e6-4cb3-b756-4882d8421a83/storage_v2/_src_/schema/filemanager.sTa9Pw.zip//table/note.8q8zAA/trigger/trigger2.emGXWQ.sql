create definer = root@localhost trigger trigger2
  before DELETE
  on note
  for each row
  update course c join note on note.userId=c.userId set noteNum=noteNum-1 where note.courseId=c.courseId;

