create definer = root@localhost trigger trigger1
  after INSERT
  on note
  for each row
  update course c join note on note.userId=c.userId set noteNum=noteNum+1 where note.courseId=c.courseId;

