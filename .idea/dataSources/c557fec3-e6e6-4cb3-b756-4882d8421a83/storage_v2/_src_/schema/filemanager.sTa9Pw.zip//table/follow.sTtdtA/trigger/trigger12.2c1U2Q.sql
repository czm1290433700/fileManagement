create definer = root@localhost trigger trigger12
  before DELETE
  on follow
  for each row
  update user join follow on user.userId=follow.followeeId set user.followNum=user.followNum-1;

