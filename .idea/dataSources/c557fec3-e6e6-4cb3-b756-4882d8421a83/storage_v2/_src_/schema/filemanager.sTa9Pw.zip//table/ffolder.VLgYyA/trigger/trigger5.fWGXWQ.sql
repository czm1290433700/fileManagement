create definer = root@localhost trigger trigger5
  after INSERT
  on ffolder
  for each row
  update course c join ffolder on ffolder.userId=c.userId set ffolderNum=ffolderNum+1 where c.courseId=ffolder.courseId;

