create definer = root@localhost trigger trigger11
  after INSERT
  on follow
  for each row
  update user join follow on user.userId=follow.followeeId set user.followNum=user.followNum+1;

