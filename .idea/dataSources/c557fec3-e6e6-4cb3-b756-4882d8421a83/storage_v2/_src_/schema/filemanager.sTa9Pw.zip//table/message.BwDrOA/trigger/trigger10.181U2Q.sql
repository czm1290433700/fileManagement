create definer = root@localhost trigger trigger10
  before DELETE
  on message
  for each row
  update user join message on user.userId=message.targetId set user.messageNum=user.messageNum-1;

