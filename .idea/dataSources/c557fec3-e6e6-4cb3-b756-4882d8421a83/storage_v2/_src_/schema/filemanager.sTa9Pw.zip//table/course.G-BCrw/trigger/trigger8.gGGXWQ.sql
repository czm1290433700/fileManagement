create definer = root@localhost trigger trigger8
  before DELETE
  on course
  for each row
  update user join course on user.userId=course.userId set user.courseNum=user.courseNum-1;

